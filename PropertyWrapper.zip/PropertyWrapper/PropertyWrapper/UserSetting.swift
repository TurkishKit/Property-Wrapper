//
//  UserSetting.swift
//  PropertyWrapper
//
//  Created by Ufuk Köşker on 24.07.2020.
//

import SwiftUI

class UserSetting: ObservableObject {
    @Published var score = 0
}
