//
//  ContentView.swift
//  PropertyWrapper
//
//  Created by Ufuk Köşker on 24.07.2020.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var setting = UserSetting()
    var body: some View {
        VStack {
            Text("Skor: \(self.setting.score)").padding()
            Button(action: {self.setting.score += 1}) {
                Text("Skoru arttır")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
