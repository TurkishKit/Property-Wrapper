//
//  PropertyWrapperApp.swift
//  PropertyWrapper
//
//  Created by Ufuk Köşker on 24.07.2020.
//

import SwiftUI

@main
struct PropertyWrapperApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
